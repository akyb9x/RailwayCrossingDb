package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;

import com.dbutil.DbUtil;

import java.sql.Connection; 
import java.sql.PreparedStatement;

import java.sql.SQLException;


/**
 * Servlet implementation class AddToFavorite
 */
public class AddToFavorite extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddToFavorite() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String itemId = request.getParameter("itemId");
		try {


			Connection conn = DbUtil.dbConn();
			String sql = "INSERT INTO favorites (id, Name, Address, Landmark, Trainschedule, pname, status) " +

			"SELECT id, Name, Address, Landmark, Trainschedule, pname, status " + "FROM adminhome WHERE id = ?";

			PreparedStatement statement = conn.prepareStatement(sql); 
			statement.setString(1, itemId);
			int rowsAffected = statement.executeUpdate();


			statement.close(); 
			conn.close();



			response.sendRedirect("userHome.jsp");

		} catch (ClassNotFoundException | SQLException e) { e.printStackTrace();

		}

	}

}
