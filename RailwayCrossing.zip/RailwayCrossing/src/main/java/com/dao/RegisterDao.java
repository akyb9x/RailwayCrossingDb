package com.dao;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import com.dbutil.DbUtil;
import com.pojo.Member;


public class RegisterDao {


	public String insert(Member member) throws ClassNotFoundException, SQLException{

		Connection conn = DbUtil.dbConn();

		String result = "Data entered successfully"; String sql = "insert into user values(?,?,?)";

		PreparedStatement ps;

		try {

			ps = conn.prepareStatement(sql);

			ps.setString(1, member.getUname()); 
			ps.setString(2, member.getPassword()); 
			ps.setString(3, member.getEmail()); 
			ps.executeUpdate();
			
		} catch (SQLException e) {

			e.printStackTrace();

			result = "Data not entered";

		}

		return result;

	}

} 
